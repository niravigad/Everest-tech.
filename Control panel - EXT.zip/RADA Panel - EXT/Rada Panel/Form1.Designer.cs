﻿namespace Rada_Panel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.DC_button_1 = new System.Windows.Forms.Button();
            this.button_GO_UUT1_Current = new System.Windows.Forms.Button();
            this.UUT1_comm = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox_UUT1_Current = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox_Comm_UUT1 = new System.Windows.Forms.TextBox();
            this.textBox_DC_UUT1 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.UUT2_comm = new System.Windows.Forms.Button();
            this.button_GO_UUT2_Current = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.DC_button_2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_UUT2_Current = new System.Windows.Forms.TextBox();
            this.textBox_DC_UUT2 = new System.Windows.Forms.TextBox();
            this.textBox_Comm_UUT2 = new System.Windows.Forms.TextBox();
            this.DC_button_4 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.ledBulb_SWITCH = new Rada_Panel.LedBulb();
            this.label18 = new System.Windows.Forms.Label();
            this.ledBulb_ARD = new Rada_Panel.LedBulb();
            this.label16 = new System.Windows.Forms.Label();
            this.ledBulb_ZUP = new Rada_Panel.LedBulb();
            this.label15 = new System.Windows.Forms.Label();
            this.ledBulb_Gen = new Rada_Panel.LedBulb();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button_GO_UUT3_Current = new System.Windows.Forms.Button();
            this.UUT3_comm = new System.Windows.Forms.Button();
            this.DC_button_3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox_DC_UUT3 = new System.Windows.Forms.TextBox();
            this.textBox_Comm_UUT3 = new System.Windows.Forms.TextBox();
            this.textBox_UUT3_Current = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.UUT4_comm = new System.Windows.Forms.Button();
            this.button_GO_UUT4_Current = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox_DC_UUT4 = new System.Windows.Forms.TextBox();
            this.textBox_UUT4_Current = new System.Windows.Forms.TextBox();
            this.textBox_Comm_UUT4 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.button_GO_SPARE = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox_DC_SPARE = new System.Windows.Forms.TextBox();
            this.GEN_ON_OFF_SW = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.ZUP_ON_OFF_SW = new System.Windows.Forms.PictureBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox_SWITCH_IP = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.timer_status = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GEN_ON_OFF_SW)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZUP_ON_OFF_SW)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.DC_button_1);
            this.panel1.Controls.Add(this.button_GO_UUT1_Current);
            this.panel1.Controls.Add(this.UUT1_comm);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.textBox_UUT1_Current);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.textBox_Comm_UUT1);
            this.panel1.Controls.Add(this.textBox_DC_UUT1);
            this.panel1.Location = new System.Drawing.Point(12, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(251, 160);
            this.panel1.TabIndex = 0;
            // 
            // DC_button_1
            // 
            this.DC_button_1.Location = new System.Drawing.Point(112, 63);
            this.DC_button_1.Name = "DC_button_1";
            this.DC_button_1.Size = new System.Drawing.Size(58, 23);
            this.DC_button_1.TabIndex = 72;
            this.DC_button_1.Text = "Go";
            this.DC_button_1.UseVisualStyleBackColor = true;
            this.DC_button_1.Click += new System.EventHandler(this.DC_UUT_TEST_Click);
            // 
            // button_GO_UUT1_Current
            // 
            this.button_GO_UUT1_Current.Location = new System.Drawing.Point(112, 122);
            this.button_GO_UUT1_Current.Name = "button_GO_UUT1_Current";
            this.button_GO_UUT1_Current.Size = new System.Drawing.Size(58, 23);
            this.button_GO_UUT1_Current.TabIndex = 71;
            this.button_GO_UUT1_Current.Text = "Go";
            this.button_GO_UUT1_Current.UseVisualStyleBackColor = true;
            this.button_GO_UUT1_Current.Click += new System.EventHandler(this.button_GO_UUT1_Current_Click);
            // 
            // UUT1_comm
            // 
            this.UUT1_comm.Location = new System.Drawing.Point(112, 93);
            this.UUT1_comm.Name = "UUT1_comm";
            this.UUT1_comm.Size = new System.Drawing.Size(58, 23);
            this.UUT1_comm.TabIndex = 71;
            this.UUT1_comm.Text = "Go";
            this.UUT1_comm.UseVisualStyleBackColor = true;
            this.UUT1_comm.Click += new System.EventHandler(this.UUT1_comm_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Self test - UUT 1";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(5, 69);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(70, 17);
            this.label42.TabIndex = 5;
            this.label42.Text = "DC Power";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(185, 46);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 17);
            this.label17.TabIndex = 69;
            this.label17.Text = "Status";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(5, 125);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 17);
            this.label38.TabIndex = 6;
            this.label38.Text = "Current";
            // 
            // textBox_UUT1_Current
            // 
            this.textBox_UUT1_Current.Location = new System.Drawing.Point(177, 125);
            this.textBox_UUT1_Current.Name = "textBox_UUT1_Current";
            this.textBox_UUT1_Current.ReadOnly = true;
            this.textBox_UUT1_Current.Size = new System.Drawing.Size(66, 20);
            this.textBox_UUT1_Current.TabIndex = 69;
            this.textBox_UUT1_Current.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(5, 96);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(104, 17);
            this.label20.TabIndex = 6;
            this.label20.Text = "Communication";
            // 
            // textBox_Comm_UUT1
            // 
            this.textBox_Comm_UUT1.Location = new System.Drawing.Point(177, 96);
            this.textBox_Comm_UUT1.Name = "textBox_Comm_UUT1";
            this.textBox_Comm_UUT1.ReadOnly = true;
            this.textBox_Comm_UUT1.Size = new System.Drawing.Size(66, 20);
            this.textBox_Comm_UUT1.TabIndex = 69;
            this.textBox_Comm_UUT1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_DC_UUT1
            // 
            this.textBox_DC_UUT1.Location = new System.Drawing.Point(177, 66);
            this.textBox_DC_UUT1.Name = "textBox_DC_UUT1";
            this.textBox_DC_UUT1.ReadOnly = true;
            this.textBox_DC_UUT1.Size = new System.Drawing.Size(66, 20);
            this.textBox_DC_UUT1.TabIndex = 68;
            this.textBox_DC_UUT1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.UUT2_comm);
            this.panel2.Controls.Add(this.button_GO_UUT2_Current);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.DC_button_2);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label39);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBox_UUT2_Current);
            this.panel2.Controls.Add(this.textBox_DC_UUT2);
            this.panel2.Controls.Add(this.textBox_Comm_UUT2);
            this.panel2.Location = new System.Drawing.Point(272, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(251, 160);
            this.panel2.TabIndex = 1;
            // 
            // UUT2_comm
            // 
            this.UUT2_comm.Location = new System.Drawing.Point(113, 93);
            this.UUT2_comm.Name = "UUT2_comm";
            this.UUT2_comm.Size = new System.Drawing.Size(58, 23);
            this.UUT2_comm.TabIndex = 78;
            this.UUT2_comm.Text = "Go";
            this.UUT2_comm.UseVisualStyleBackColor = true;
            this.UUT2_comm.Click += new System.EventHandler(this.UUT2_comm_Click);
            // 
            // button_GO_UUT2_Current
            // 
            this.button_GO_UUT2_Current.Location = new System.Drawing.Point(113, 122);
            this.button_GO_UUT2_Current.Name = "button_GO_UUT2_Current";
            this.button_GO_UUT2_Current.Size = new System.Drawing.Size(58, 23);
            this.button_GO_UUT2_Current.TabIndex = 71;
            this.button_GO_UUT2_Current.Text = "Go";
            this.button_GO_UUT2_Current.UseVisualStyleBackColor = true;
            this.button_GO_UUT2_Current.Click += new System.EventHandler(this.button_GO_UUT2_Current_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(53, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 20);
            this.label8.TabIndex = 69;
            this.label8.Text = "Self test - UUT 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 17);
            this.label4.TabIndex = 72;
            this.label4.Text = "DC Power";
            // 
            // DC_button_2
            // 
            this.DC_button_2.Location = new System.Drawing.Point(113, 66);
            this.DC_button_2.Name = "DC_button_2";
            this.DC_button_2.Size = new System.Drawing.Size(58, 23);
            this.DC_button_2.TabIndex = 74;
            this.DC_button_2.Text = "Go";
            this.DC_button_2.UseVisualStyleBackColor = true;
            this.DC_button_2.Click += new System.EventHandler(this.DC_UUT_TEST_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(186, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 17);
            this.label2.TabIndex = 76;
            this.label2.Text = "Status";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(6, 125);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(55, 17);
            this.label39.TabIndex = 6;
            this.label39.Text = "Current";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 17);
            this.label3.TabIndex = 73;
            this.label3.Text = "Communication";
            // 
            // textBox_UUT2_Current
            // 
            this.textBox_UUT2_Current.Location = new System.Drawing.Point(178, 125);
            this.textBox_UUT2_Current.Name = "textBox_UUT2_Current";
            this.textBox_UUT2_Current.ReadOnly = true;
            this.textBox_UUT2_Current.Size = new System.Drawing.Size(66, 20);
            this.textBox_UUT2_Current.TabIndex = 69;
            this.textBox_UUT2_Current.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_DC_UUT2
            // 
            this.textBox_DC_UUT2.Location = new System.Drawing.Point(178, 66);
            this.textBox_DC_UUT2.Name = "textBox_DC_UUT2";
            this.textBox_DC_UUT2.ReadOnly = true;
            this.textBox_DC_UUT2.Size = new System.Drawing.Size(66, 20);
            this.textBox_DC_UUT2.TabIndex = 75;
            this.textBox_DC_UUT2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Comm_UUT2
            // 
            this.textBox_Comm_UUT2.Location = new System.Drawing.Point(178, 96);
            this.textBox_Comm_UUT2.Name = "textBox_Comm_UUT2";
            this.textBox_Comm_UUT2.ReadOnly = true;
            this.textBox_Comm_UUT2.Size = new System.Drawing.Size(66, 20);
            this.textBox_Comm_UUT2.TabIndex = 77;
            this.textBox_Comm_UUT2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DC_button_4
            // 
            this.DC_button_4.Location = new System.Drawing.Point(114, 63);
            this.DC_button_4.Name = "DC_button_4";
            this.DC_button_4.Size = new System.Drawing.Size(58, 23);
            this.DC_button_4.TabIndex = 74;
            this.DC_button_4.Text = "Go";
            this.DC_button_4.UseVisualStyleBackColor = true;
            this.DC_button_4.Click += new System.EventHandler(this.DC_UUT_TEST_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.ledBulb_SWITCH);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.ledBulb_ARD);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.ledBulb_ZUP);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.ledBulb_Gen);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Location = new System.Drawing.Point(272, 391);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(251, 128);
            this.panel4.TabIndex = 10;
            // 
            // ledBulb_SWITCH
            // 
            this.ledBulb_SWITCH.Location = new System.Drawing.Point(147, 93);
            this.ledBulb_SWITCH.Name = "ledBulb_SWITCH";
            this.ledBulb_SWITCH.On = true;
            this.ledBulb_SWITCH.Size = new System.Drawing.Size(23, 23);
            this.ledBulb_SWITCH.TabIndex = 15;
            this.ledBulb_SWITCH.Text = "ledBulb1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(175, 93);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(48, 17);
            this.label18.TabIndex = 14;
            this.label18.Text = "Switch";
            // 
            // ledBulb_ARD
            // 
            this.ledBulb_ARD.Location = new System.Drawing.Point(147, 50);
            this.ledBulb_ARD.Name = "ledBulb_ARD";
            this.ledBulb_ARD.On = true;
            this.ledBulb_ARD.Size = new System.Drawing.Size(23, 23);
            this.ledBulb_ARD.TabIndex = 15;
            this.ledBulb_ARD.Text = "ledBulb1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(175, 50);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 17);
            this.label16.TabIndex = 10;
            this.label16.Text = "Arduino";
            // 
            // ledBulb_ZUP
            // 
            this.ledBulb_ZUP.Location = new System.Drawing.Point(19, 93);
            this.ledBulb_ZUP.Name = "ledBulb_ZUP";
            this.ledBulb_ZUP.On = true;
            this.ledBulb_ZUP.Size = new System.Drawing.Size(23, 23);
            this.ledBulb_ZUP.TabIndex = 15;
            this.ledBulb_ZUP.Text = "ledBulb1";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(47, 93);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 17);
            this.label15.TabIndex = 8;
            this.label15.Text = "ZUP 36-24";
            // 
            // ledBulb_Gen
            // 
            this.ledBulb_Gen.Location = new System.Drawing.Point(19, 50);
            this.ledBulb_Gen.Name = "ledBulb_Gen";
            this.ledBulb_Gen.On = true;
            this.ledBulb_Gen.Size = new System.Drawing.Size(23, 23);
            this.ledBulb_Gen.TabIndex = 15;
            this.ledBulb_Gen.Text = "ledBulb1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(47, 50);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 17);
            this.label14.TabIndex = 6;
            this.label14.Text = "Gen 30-50";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(53, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(132, 20);
            this.label13.TabIndex = 4;
            this.label13.Text = "Communication";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(46, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(144, 20);
            this.label12.TabIndex = 70;
            this.label12.Text = "Self test - UUT 3";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.button_GO_UUT3_Current);
            this.panel5.Controls.Add(this.UUT3_comm);
            this.panel5.Controls.Add(this.DC_button_3);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.label41);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.textBox_DC_UUT3);
            this.panel5.Controls.Add(this.textBox_Comm_UUT3);
            this.panel5.Controls.Add(this.textBox_UUT3_Current);
            this.panel5.Location = new System.Drawing.Point(12, 225);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(251, 160);
            this.panel5.TabIndex = 50;
            // 
            // button_GO_UUT3_Current
            // 
            this.button_GO_UUT3_Current.Location = new System.Drawing.Point(113, 123);
            this.button_GO_UUT3_Current.Name = "button_GO_UUT3_Current";
            this.button_GO_UUT3_Current.Size = new System.Drawing.Size(58, 23);
            this.button_GO_UUT3_Current.TabIndex = 71;
            this.button_GO_UUT3_Current.Text = "Go";
            this.button_GO_UUT3_Current.UseVisualStyleBackColor = true;
            this.button_GO_UUT3_Current.Click += new System.EventHandler(this.button_GO_UUT3_Current_Click);
            // 
            // UUT3_comm
            // 
            this.UUT3_comm.Location = new System.Drawing.Point(113, 93);
            this.UUT3_comm.Name = "UUT3_comm";
            this.UUT3_comm.Size = new System.Drawing.Size(58, 23);
            this.UUT3_comm.TabIndex = 78;
            this.UUT3_comm.Text = "Go";
            this.UUT3_comm.UseVisualStyleBackColor = true;
            this.UUT3_comm.Click += new System.EventHandler(this.UUT3_comm_Click);
            // 
            // DC_button_3
            // 
            this.DC_button_3.Location = new System.Drawing.Point(113, 66);
            this.DC_button_3.Name = "DC_button_3";
            this.DC_button_3.Size = new System.Drawing.Size(58, 23);
            this.DC_button_3.TabIndex = 74;
            this.DC_button_3.Text = "Go";
            this.DC_button_3.UseVisualStyleBackColor = true;
            this.DC_button_3.Click += new System.EventHandler(this.DC_UUT_TEST_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 17);
            this.label6.TabIndex = 72;
            this.label6.Text = "DC Power";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(186, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 17);
            this.label7.TabIndex = 76;
            this.label7.Text = "Status";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(6, 126);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(55, 17);
            this.label41.TabIndex = 6;
            this.label41.Text = "Current";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(6, 96);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(104, 17);
            this.label22.TabIndex = 73;
            this.label22.Text = "Communication";
            // 
            // textBox_DC_UUT3
            // 
            this.textBox_DC_UUT3.Location = new System.Drawing.Point(178, 66);
            this.textBox_DC_UUT3.Name = "textBox_DC_UUT3";
            this.textBox_DC_UUT3.ReadOnly = true;
            this.textBox_DC_UUT3.Size = new System.Drawing.Size(66, 20);
            this.textBox_DC_UUT3.TabIndex = 75;
            this.textBox_DC_UUT3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Comm_UUT3
            // 
            this.textBox_Comm_UUT3.Location = new System.Drawing.Point(178, 96);
            this.textBox_Comm_UUT3.Name = "textBox_Comm_UUT3";
            this.textBox_Comm_UUT3.ReadOnly = true;
            this.textBox_Comm_UUT3.Size = new System.Drawing.Size(66, 20);
            this.textBox_Comm_UUT3.TabIndex = 77;
            this.textBox_Comm_UUT3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_UUT3_Current
            // 
            this.textBox_UUT3_Current.Location = new System.Drawing.Point(178, 126);
            this.textBox_UUT3_Current.Name = "textBox_UUT3_Current";
            this.textBox_UUT3_Current.ReadOnly = true;
            this.textBox_UUT3_Current.Size = new System.Drawing.Size(66, 20);
            this.textBox_UUT3_Current.TabIndex = 69;
            this.textBox_UUT3_Current.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.UUT4_comm);
            this.panel8.Controls.Add(this.button_GO_UUT4_Current);
            this.panel8.Controls.Add(this.label5);
            this.panel8.Controls.Add(this.DC_button_4);
            this.panel8.Controls.Add(this.label23);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.label40);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.textBox_DC_UUT4);
            this.panel8.Controls.Add(this.textBox_UUT4_Current);
            this.panel8.Controls.Add(this.textBox_Comm_UUT4);
            this.panel8.Location = new System.Drawing.Point(272, 225);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(251, 160);
            this.panel8.TabIndex = 51;
            // 
            // UUT4_comm
            // 
            this.UUT4_comm.Location = new System.Drawing.Point(113, 93);
            this.UUT4_comm.Name = "UUT4_comm";
            this.UUT4_comm.Size = new System.Drawing.Size(58, 23);
            this.UUT4_comm.TabIndex = 78;
            this.UUT4_comm.Text = "Go";
            this.UUT4_comm.UseVisualStyleBackColor = true;
            this.UUT4_comm.Click += new System.EventHandler(this.UUT4_comm_Click);
            // 
            // button_GO_UUT4_Current
            // 
            this.button_GO_UUT4_Current.Location = new System.Drawing.Point(113, 122);
            this.button_GO_UUT4_Current.Name = "button_GO_UUT4_Current";
            this.button_GO_UUT4_Current.Size = new System.Drawing.Size(58, 23);
            this.button_GO_UUT4_Current.TabIndex = 71;
            this.button_GO_UUT4_Current.Text = "Go";
            this.button_GO_UUT4_Current.UseVisualStyleBackColor = true;
            this.button_GO_UUT4_Current.Click += new System.EventHandler(this.button_GO_UUT4_Current_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(53, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 20);
            this.label5.TabIndex = 69;
            this.label5.Text = "Self test - UUT 4";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 69);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(70, 17);
            this.label23.TabIndex = 72;
            this.label23.Text = "DC Power";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(186, 46);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 17);
            this.label24.TabIndex = 76;
            this.label24.Text = "Status";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(6, 125);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(55, 17);
            this.label40.TabIndex = 6;
            this.label40.Text = "Current";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 96);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(104, 17);
            this.label25.TabIndex = 73;
            this.label25.Text = "Communication";
            // 
            // textBox_DC_UUT4
            // 
            this.textBox_DC_UUT4.Location = new System.Drawing.Point(178, 66);
            this.textBox_DC_UUT4.Name = "textBox_DC_UUT4";
            this.textBox_DC_UUT4.ReadOnly = true;
            this.textBox_DC_UUT4.Size = new System.Drawing.Size(66, 20);
            this.textBox_DC_UUT4.TabIndex = 75;
            this.textBox_DC_UUT4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_UUT4_Current
            // 
            this.textBox_UUT4_Current.Location = new System.Drawing.Point(178, 125);
            this.textBox_UUT4_Current.Name = "textBox_UUT4_Current";
            this.textBox_UUT4_Current.ReadOnly = true;
            this.textBox_UUT4_Current.Size = new System.Drawing.Size(66, 20);
            this.textBox_UUT4_Current.TabIndex = 69;
            this.textBox_UUT4_Current.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Comm_UUT4
            // 
            this.textBox_Comm_UUT4.Location = new System.Drawing.Point(178, 96);
            this.textBox_Comm_UUT4.Name = "textBox_Comm_UUT4";
            this.textBox_Comm_UUT4.ReadOnly = true;
            this.textBox_Comm_UUT4.Size = new System.Drawing.Size(66, 20);
            this.textBox_Comm_UUT4.TabIndex = 77;
            this.textBox_Comm_UUT4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.button_GO_SPARE);
            this.panel6.Controls.Add(this.label21);
            this.panel6.Controls.Add(this.label26);
            this.panel6.Controls.Add(this.textBox_DC_SPARE);
            this.panel6.Location = new System.Drawing.Point(12, 391);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(251, 128);
            this.panel6.TabIndex = 52;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(53, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(141, 20);
            this.label19.TabIndex = 69;
            this.label19.Text = "Self test - Spare";
            // 
            // button_GO_SPARE
            // 
            this.button_GO_SPARE.Location = new System.Drawing.Point(113, 66);
            this.button_GO_SPARE.Name = "button_GO_SPARE";
            this.button_GO_SPARE.Size = new System.Drawing.Size(58, 23);
            this.button_GO_SPARE.TabIndex = 74;
            this.button_GO_SPARE.Text = "Go";
            this.button_GO_SPARE.UseVisualStyleBackColor = true;
            this.button_GO_SPARE.Click += new System.EventHandler(this.button_GO_SPARE_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(6, 69);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 17);
            this.label21.TabIndex = 72;
            this.label21.Text = "DC Power";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(186, 46);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 17);
            this.label26.TabIndex = 76;
            this.label26.Text = "Status";
            // 
            // textBox_DC_SPARE
            // 
            this.textBox_DC_SPARE.Location = new System.Drawing.Point(178, 66);
            this.textBox_DC_SPARE.Name = "textBox_DC_SPARE";
            this.textBox_DC_SPARE.ReadOnly = true;
            this.textBox_DC_SPARE.Size = new System.Drawing.Size(66, 20);
            this.textBox_DC_SPARE.TabIndex = 75;
            this.textBox_DC_SPARE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GEN_ON_OFF_SW
            // 
            this.GEN_ON_OFF_SW.BackColor = System.Drawing.Color.LightGray;
            this.GEN_ON_OFF_SW.BackgroundImage = global::Rada_Panel.Properties.Resources.OFF1;
            this.GEN_ON_OFF_SW.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.GEN_ON_OFF_SW.Location = new System.Drawing.Point(140, 38);
            this.GEN_ON_OFF_SW.Name = "GEN_ON_OFF_SW";
            this.GEN_ON_OFF_SW.Size = new System.Drawing.Size(71, 28);
            this.GEN_ON_OFF_SW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GEN_ON_OFF_SW.TabIndex = 53;
            this.GEN_ON_OFF_SW.TabStop = false;
            this.GEN_ON_OFF_SW.Tag = "0";
            this.GEN_ON_OFF_SW.Click += new System.EventHandler(this.GEN_ON_OFF_SW_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(202, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 20);
            this.label9.TabIndex = 54;
            this.label9.Text = "P.S Control";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.ZUP_ON_OFF_SW);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.GEN_ON_OFF_SW);
            this.panel3.Controls.Add(this.label29);
            this.panel3.Location = new System.Drawing.Point(12, 525);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(511, 83);
            this.panel3.TabIndex = 15;
            // 
            // ZUP_ON_OFF_SW
            // 
            this.ZUP_ON_OFF_SW.BackColor = System.Drawing.Color.LightGray;
            this.ZUP_ON_OFF_SW.BackgroundImage = global::Rada_Panel.Properties.Resources.OFF1;
            this.ZUP_ON_OFF_SW.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ZUP_ON_OFF_SW.Location = new System.Drawing.Point(386, 37);
            this.ZUP_ON_OFF_SW.Name = "ZUP_ON_OFF_SW";
            this.ZUP_ON_OFF_SW.Size = new System.Drawing.Size(71, 28);
            this.ZUP_ON_OFF_SW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ZUP_ON_OFF_SW.TabIndex = 54;
            this.ZUP_ON_OFF_SW.TabStop = false;
            this.ZUP_ON_OFF_SW.Tag = "0";
            this.ZUP_ON_OFF_SW.Click += new System.EventHandler(this.ZUP_ON_OFF_SW_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(293, 44);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(77, 17);
            this.label28.TabIndex = 8;
            this.label28.Text = "ZUP 36-24";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(47, 44);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(76, 17);
            this.label29.TabIndex = 6;
            this.label29.Text = "Gen 30-50";
            // 
            // textBox_SWITCH_IP
            // 
            this.textBox_SWITCH_IP.Location = new System.Drawing.Point(115, 33);
            this.textBox_SWITCH_IP.MaxLength = 15;
            this.textBox_SWITCH_IP.Name = "textBox_SWITCH_IP";
            this.textBox_SWITCH_IP.ReadOnly = true;
            this.textBox_SWITCH_IP.Size = new System.Drawing.Size(109, 20);
            this.textBox_SWITCH_IP.TabIndex = 53;
            this.textBox_SWITCH_IP.Text = "10.10.0.200";
            this.textBox_SWITCH_IP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_SWITCH_IP.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_SWITCH_IP_KeyDown);
            this.textBox_SWITCH_IP.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseDoubleClick);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(8, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "Switch IP:";
            // 
            // timer_status
            // 
            this.timer_status.Enabled = true;
            this.timer_status.Interval = 3000;
            this.timer_status.Tick += new System.EventHandler(this.timer_status_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 618);
            this.Controls.Add(this.textBox_SWITCH_IP);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Preparation Station Operating Panel";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GEN_ON_OFF_SW)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZUP_ON_OFF_SW)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        //private Bulb.LedBulb ledBulb_Ard;
        private System.Windows.Forms.Label label15;
        //private Bulb.LedBulb ledBulb_Zup;
        private System.Windows.Forms.Label label14;
        //private Bulb.LedBulb ledBulb_Lambda;
        private System.Windows.Forms.Label label18;
        //private Bulb.LedBulb ledBulb_Switch;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox_Comm_UUT1;
        private System.Windows.Forms.TextBox textBox_DC_UUT1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button UUT1_comm;
        private System.Windows.Forms.Button UUT2_comm;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button DC_button_4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_DC_UUT2;
        private System.Windows.Forms.TextBox textBox_Comm_UUT2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button UUT3_comm;
        private System.Windows.Forms.Button DC_button_3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox_DC_UUT3;
        private System.Windows.Forms.TextBox textBox_Comm_UUT3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button UUT4_comm;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button DC_button_2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox_DC_UUT4;
        private System.Windows.Forms.TextBox textBox_Comm_UUT4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button_GO_SPARE;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox_DC_SPARE;
        private System.Windows.Forms.Button DC_button_1;
        private System.Windows.Forms.PictureBox GEN_ON_OFF_SW;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox ZUP_ON_OFF_SW;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button_GO_UUT1_Current;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox_UUT1_Current;
        private System.Windows.Forms.Button button_GO_UUT2_Current;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox_UUT2_Current;
        private System.Windows.Forms.Button button_GO_UUT3_Current;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox_UUT3_Current;
        private System.Windows.Forms.Button button_GO_UUT4_Current;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox_UUT4_Current;
        private Rada_Panel.LedBulb ledBulb_Gen = new LedBulb();
        private Rada_Panel.LedBulb ledBulb_ZUP = new LedBulb();
        private Rada_Panel.LedBulb ledBulb_ARD = new LedBulb();
        private Rada_Panel.LedBulb ledBulb_SWITCH = new LedBulb();
        private System.Windows.Forms.TextBox textBox_SWITCH_IP;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Timer timer_status;
    }
}

