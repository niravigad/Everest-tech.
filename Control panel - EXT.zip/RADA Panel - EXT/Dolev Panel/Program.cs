﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rada_Panel
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            _LambdaAdd = System.Configuration.ConfigurationManager.AppSettings["LambdaCom"];
            _ZupAdd = System.Configuration.ConfigurationManager.AppSettings["ZupCom"];
            _ArduinoAdd = System.Configuration.ConfigurationManager.AppSettings["ArduinoCom"];            
            _mySerialPort = System.Configuration.ConfigurationManager.AppSettings["mySerialPort"];            
            Application.Run(new Form1(_LambdaAdd, _ZupAdd, _ArduinoAdd,  _mySerialPort));
        }

        static public string _mySerialPort;
        static public string _ArduinoAdd;
        static public string _LambdaAdd;
        static public string _ZupAdd;        

    }
}
